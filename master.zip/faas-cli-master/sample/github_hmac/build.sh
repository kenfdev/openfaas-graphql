#!/bin/sh

echo "Building alexellis2/hmac" 
docker build -t alexellis2/hmac .

