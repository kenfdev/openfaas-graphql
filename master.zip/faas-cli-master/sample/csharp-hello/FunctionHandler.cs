﻿using System;
using System.Text;

namespace Function
{
    public class FunctionHandler
    {
        public void Handle(string input) {
            Console.WriteLine("It's your function here. The input was: "+ input);
        }
    }
}
