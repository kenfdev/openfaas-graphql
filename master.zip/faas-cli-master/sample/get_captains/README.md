This sample function uses the Node.js `cheerio` module to parse the list of Docker Captains and return some metadata in JSON format.
